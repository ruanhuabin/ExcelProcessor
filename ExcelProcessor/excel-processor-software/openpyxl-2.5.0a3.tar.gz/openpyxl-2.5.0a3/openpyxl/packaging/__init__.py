"""
Stuff related to Office OpenXML packaging: relationships, archive, content types.
"""
